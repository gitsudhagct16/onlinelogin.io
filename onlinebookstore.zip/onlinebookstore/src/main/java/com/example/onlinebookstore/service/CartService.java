package com.example.onlinebookstore.service;

import com.example.onlinebookstore.model.Book;
import com.example.onlinebookstore.model.CartItem;
import com.example.onlinebookstore.repository.BookRepository;
import com.example.onlinebookstore.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartItemRepository cartItemRepository;
    @Autowired
    private BookRepository bookRepository;

    public List<CartItem> getCartItems() {
        return cartItemRepository.findAll();
    }

    public CartItem addToCart(Long bookId, int quantity) {
        Book book = bookRepository.findById(bookId).orElseThrow();
        CartItem item = new CartItem();
        item.setBook(book);
        item.setQuantity(quantity);
        return cartItemRepository.save(item);
    }

    public CartItem updateCartItem(Long bookId, int quantity) {
        CartItem item = cartItemRepository.findAll().stream()
                .filter(ci -> ci.getBook().getId().equals(bookId))
                .findFirst().orElseThrow();
        item.setQuantity(quantity);
        return cartItemRepository.save(item);
    }

    public void removeCartItem(Long bookId) {
        cartItemRepository.findAll().stream()
                .filter(ci -> ci.getBook().getId().equals(bookId))
                .findFirst()
                .ifPresent(cartItemRepository::delete);
    }

    public void checkout() {
        cartItemRepository.deleteAll();
    }
}
