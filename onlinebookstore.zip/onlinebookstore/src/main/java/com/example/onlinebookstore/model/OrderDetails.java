package com.example.onlinebookstore.model;

public class OrderDetails {
}
