package com.example.onlinebookstore.controller;

import com.example.onlinebookstore.model.CartItem;
import com.example.onlinebookstore.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {
    @Autowired
    private CartService cartService;

    @GetMapping
    public List<CartItem> getCart() {
        return cartService.getCartItems();
    }

    @PostMapping
    public CartItem addToCart(@RequestBody Map<String, Object> payload) {
        Long bookId = Long.valueOf(payload.get("bookId").toString());
        int quantity = Integer.parseInt(payload.get("quantity").toString());
        return cartService.addToCart(bookId, quantity);
    }

    @PutMapping("/{bookId}")
    public CartItem updateCart(@PathVariable Long bookId, @RequestBody Map<String, Object> payload) {
        int quantity = Integer.parseInt(payload.get("quantity").toString());
        return cartService.updateCartItem(bookId, quantity);
    }

    @DeleteMapping("/{bookId}")
    public void removeCartItem(@PathVariable Long bookId) {
        cartService.removeCartItem(bookId);
    }
}
