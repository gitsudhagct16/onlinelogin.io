package com.example.onlinebookstore.controller;

import com.example.onlinebookstore.model.CartItem;
import com.example.onlinebookstore.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping
    public ResponseEntity<List<CartItem>> getCart() {
        return ResponseEntity.ok(cartService.getCartItems());
    }

    @PostMapping
    public ResponseEntity<CartItem> addToCart(@RequestBody Map<String, Object> payload) {
        Long bookId = Long.valueOf(payload.get("bookId").toString());
        int quantity = Integer.parseInt(payload.get("quantity").toString());
        CartItem item = cartService.addToCart(bookId, quantity);
        return ResponseEntity.status(201).body(item); // 201 Created
    }

    @PutMapping("/{bookId}")
    public ResponseEntity<CartItem> updateCart(@PathVariable Long bookId, @RequestBody Map<String, Object> payload) {
        int quantity = Integer.parseInt(payload.get("quantity").toString());
        CartItem updatedItem = cartService.updateCartItem(bookId, quantity);
        return ResponseEntity.ok(updatedItem);
    }

    @DeleteMapping("/{bookId}")
    public ResponseEntity<Void> removeCartItem(@PathVariable Long bookId) {
        cartService.removeCartItem(bookId);
        return ResponseEntity.noContent().build(); // 204 No Content
    }
}
